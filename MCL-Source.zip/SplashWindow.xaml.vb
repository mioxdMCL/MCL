Imports System.Windows.Media.Animation
Imports System.Windows.Threading

Public Class SplashWindow

    Private Stopped As Boolean

    Public Sub New()
        InitializeComponent()
        '进度动画：3 秒从 0 平滑走到 100，走满后自动关闭闪屏
        Dim Anim As New DoubleAnimation(0, 100, New TimeSpan(0, 0, 0, 3)) With {
            .EasingFunction = New QuadraticEase With {.EasingMode = EasingMode.EaseOut}
        }
        AddHandler Anim.Completed, Sub() TryClose()
        ProgressBar.BeginAnimation(ProgressBar.ValueProperty, Anim)
    End Sub

    Public Property ProgressValue As Integer
        Get
            Return CInt(ProgressBar.Value)
        End Get
        Set(value As Integer)
            ProgressSet(value)
        End Set
    End Property

    Private Sub ProgressSet(value As Integer)
        ProgressBar.Value = Math.Min(value, 100)
    End Sub

    Public Overloads Sub Close(delay As TimeSpan)
        Stopped = True
        Dim Timer As New DispatcherTimer With {.Interval = delay}
        AddHandler Timer.Tick, Sub()
                                   Timer.Stop()
                                   TryClose()
                               End Sub
        Timer.Start()
    End Sub

    Private Sub TryClose()
        If Not IsLoaded Then Return
        Close()
    End Sub

End Class
